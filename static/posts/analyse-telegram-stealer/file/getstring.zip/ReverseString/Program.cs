﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ReverseString
{
    class Program
	{
		private readonly byte[] _key;
		private readonly byte[] _authKey;
		private static readonly byte[] Salt = new byte[]
		{
			191,
			235,
			30,
			86,
			251,
			205,
			151,
			59,
			178,
			25,
			2,
			36,
			48,
			165,
			120,
			67,
			0,
			61,
			86,
			68,
			210,
			30,
			98,
			185,
			212,
			241,
			128,
			231,
			230,
			195,
			57,
			65
		};
		public static string TelegramToken = "Bz+E5PIP2hOEyF5DxjZ7PZZJhxMatoTxvtSFWogATJzm+yu/FB2YNf4syCnYwrwuFi7ffRjL509zzGxPKSxZtpou+oEOJD/RDnZjG8UnPIctoihtVR0591ETQ5bVSvAt";

		public static X509Certificate2 ServerCertificate;
		public static string TelegramChatID = "lSHi4NceY2hON+M0jIL79+nmhtgCq+DGMaAX/iw1hPEPr4wE3zpHpQoKocwNCBPBz2pKDSHbBiPBvN//pwh9Cg==";
		public static string Ports = "RP4x6MqTac3l3jmDFkf5UJ0FB5fVLTNqmOCBk/v+dkMj3CIUpWA+/1oV4t1Ai9OAqCy5SGegDL1WZyNlFBJa2Q==";
		public static string Hosts = "lq/XKO+/JNTRlBuolsr9FBsfDiviKk22znPUCgPn81pjobe5sWbjjnfOxogxwlALJ+7mqeOQgzhDfIJ65UE7Cw==";
		public static string Version = "LimiZuwNfpX9HyoiVIamR5DbqvxCv+r1amxsFvP/6e98u8MLxyziwWUECjyyGSWXxil4yrcjR7tUG8W5xHcJKg==";
		public static string Install = "OHNX4j+4lkh83eLHMqZLQLzvNWMJdbUeMa51CgtwvfJcD7F8PkP87MAkhfBQh7M8kYRCyvgWbIw51R1NrqFifg==";
		public static string InstallFolder = "%AppData%";
		public static string InstallFile = "";
		public static string MTX = "myngrFbV/kge/PVvK2WTkIVsfxZHPHxNKWXoW98mIJ5hrVLkOergKsbI7Lt9VGERS/aywbB3e+giQLmP/X7UocHgUlTC8tUWG0kOR5oRp34=";
		public static string Certificate = "twcGCq3Zmf6f5w19s9rPH1+kqgcmlLV8vaX9YGohyQ7rpke8OotnmFY0AUQk7ifw87YrLTHLYj1m4UR5/a2WH3ZbTsKBe1a+HQtlD8fwVp/y/u8LN433WrBBHrkRxp6ACEAUtvBWrqLD7VSg7KiEQ05EnTVUUFwnuLYv8BANXRJlPx6DtXIVbmmRoo0KqCOGYD2YcQvNVPq0mpK7lRsMUPfEZp0ZZM5Z8S8JpzlQrJWR6iGrAbKAtQJBr6Y2TMCzb02Nofe4SyDxqrKuIUHjsA+GMuk3Pqu0KCH50V0HwvT3lcqrAt8gzb5vXahEs6Fmv/q70kMn6hMfLVfSqeZqwFfQwPhRwP80IWREhgjtjjetGUMSJ9hmPd247t8yOc2oUdCAirkGOIdVUl00QWmR5J4jfR/leITw5NFocvorGM5xIVLazO2YxNZnqlRozPEgBSwSBmfyRnph833KiOieoGDMyEjfpWOHuBIufk34x3LSwWI4pX75jJB8lrrkMVhADprUr2Thu7DOl5o/bZvNjs6hGOXEbeH96VBuHHoKNkDHP1VvPgKfTcg9JSfRbuI4j7hhUxLa/s30IztXkvAWYGTjspp7BTBfcS3ZB2GGJBE7Xz7ZLeTU9HHoe4e2ceF6k3qsn9TLZdVa02oHHQLWTvTzII9lPkx1V4d19fg9KppZwZVC9OFmv9vKHw2hWM2iO0OWrrgZ+/BH4V99JJQEQYv4/eoLKBGSDkPJNXtQ/PegrT2cKj24GZdF99FSOI3T6RIGVpLPWfEx55TU0KuxKmoQhPcrn9hffqZ5S92+97opp3XUq+W3C8qzkpAERQzxi7kmPctIY9ljsjYAFZFBq8rD7i59WRjvIHk0o0cR9vv6t1THRt0DOFGjfMOLBPJE46RQPpZI4ZvnVROUanXEnbKTJ/9036o0TZ9328ur0n4537smBPhqnUQeL9Y7Tvgh0wBh0XtWFzMRs3ro53FlMbjSI7SeeP+79lvoc/vOcoiWLRcuh4pCdFr9ZPoVq6pXi0HWsF2Yg8xnduZjLeSe5g8FtjNFgmmZBols4ljbBOGzZieT1Niupxygh8SP1dOjjYcdW+Qr+BP55Xy0gNGznDo0d06ZfNjDmHBu1dOK8j3fxdEO/l4jVNj0C+b68PnREzMAYUWnHsIfCE4ltqGc6gnxyJUGZHk4eVxd94J0oFdNqTsdfek37KcvGrKk2kuK+gr90ZO8y+gsLuzS1loiQIBXuzcaJv5OekhdK0krFm2fhTYgimrXcL5D9lYWvo9c3o7QZQzSOw+nVQMIOhrWUtp7qN5Ni5fFZeIgPPqKUuA+02gy4DEYy8XF2rIRNeJIpbx6Xq4QuiMjQtVAF3v5N80eFc6O/yDTiQUTl7lW9jZvZQgS52sIXInfByfLVchsq1tz0HcN0DLLUFjGPjQLLbsYyNW7iZotNAifQMfpAL62LvrWtR0ocfUxOdSVUtCgIubFavz0c/pXZ205TGb4Pd8oWsT1EV3unwokgM/pDt3T7Pbkyifm/OwVln8FoAjTJ9KZ4chIB5Isl2MQSw13dqYoSNgD8IJLA91qEjgq4r1C6cxCSkSPTZkuWRk6E6a8YHqaQmL2l2p9Qd8w1BsX+xUiZxmYOkLJYsrnXCaXNBfCRFh85kF8mIFhY1OStJnsBUheyLELKvpfsk+NRefc8X9KpKHq/1kHLq9kkdS/aBOn36Gccdy67GsUzvtcqUZDvKL+NY2mcYYzNDDZ8RGd0CDg8xb32PG2UUlDxiS2L5bdr7Oj4yNkGAKF+Rw+aaJ8/+4PO8mbPDKfD3iTA5Z7GRj1IhSBVZbZayYdSH0LCKPuDD3HMi6M8C9nqYiA6bQ5qq4NZta7zlb9Itxl57jLgWjG9L7S4oqTkuNQm4lEqDsNq6Hd92f+QKucC3iG3siPSChBBFELi19qvE6ULuYF7jXuYZMcyWgBP0j9DS2ymYENSCRBbTvENRauY2VQT+8dDoJUWawxs+QZ48kk2Eae8bfynCVIo579ImQC4TLoX4RQ6/efyTAy36i8lZ7WoHevsVDjyiMUr5avxhKf+5BFouffkzQeYOnJXXGezoIHIaETb5cSAHUDBQfh4pdiy26IE9TfQGxPVBsz5DL4ureKQrINKFrKEuR4LghbFaVC+XeheWZGtZBfUmt+VDyujJDuUmE8Qjc7rlG7LEt24DxZGkahhkktKqXqWnw129gS2KJPEysp0kWb7TS7Leyu3MnLU5YkcfCJ8WubMXmfsWIHBTZxIZjnQJgGPw9lpH/2xRU63rrKYJbP0snQw6LHWOvFbwdpiwh7WcUGTB5e7M78TF90Eh7ZSHJJ31GucxRK4e4=";
		public static string Serversignature = "e1URW1RCDMD6zcM9dbws1h8Rlgth4aD+g8WA5+4UqOof/zo37z/oi6nNCeia1OPFzKFXWrFvOsxOAN2WhH0uyoRFPKhEzesiQJYeA+TsTZQmnAaPbsFm2NyAPoeR7024ozcYVCWJFjWlSNmt4XwlqqFMiTNJmum8YVVIPp0IY+TzpU6ovhgbNZnYQQcjD3CnoagcEwKK4JSHqJa92YatRWht7w6+eHQ8lO6S6I+Y7bWR/ouISvqWuNNq4ziJpPgsiXuXDO6Hf2o1s04Qro5GsLD7qBy874lNy8dRXF8gPojdnYoZ/aGG9WF46BJ0Ky9kdH5bJ1zXeqbIX2kiLtAkWLKPKkzDIXK3UK4TDYk/Rlj0hjq4hWdImN5FRH/60503pht59W87la0YaLS35GnZk+5tYidmn7iFPDzZZJ4+rPIyaBRkLpnNrxUpn+QKIcqUuObMhjAydEByVUcTEdoFciDmDswGElyyjdYk51RJuxtn3BUU8cQKgpxA879nslabyrlPawb3PY1mED/+fzx1Hzt+W8yOWa1smrCt7kaa8W/23GDP40NaedampwfeLcGfyXPdPsIG21kDUCaQhgJkkrtfCXKjucvjYVDYHaRLVyVsGrAfIVjNhcvHW6jzI+J5Op6zMkoQD7XDEVMtau/2UIx6AqQi9CyzbRFKMIkmOEiZaAVIn5VgoDZ70OJoFZs/bcEqRsI/TnHVmWk0mHUxqaf9W1XWfau5Ip2RX8rVPi7zX6u/o9SZfEamQk3POTaipBVbppWQ6CPZHTgT0wSP78Ch4LibTq3uCVHcroGZ3BqIDOeSwnyEbxkFqxVgz3dJlI64N+vCqCewfRvt5GGironWTvCzOY7XcIi5A3j2JllmMDhRmhFCENjF6a1Ju71RtE9maSSD9blwB0URTSO0C8thm3ssDn0FyFRewMHNg9aA2XU7qE1MhkEQd+qZ++Sp6V7JgUUsiYTeLrIVFfhl4Q==";
		public static string Anti = "NFz90hvWuR4pvNJE0u0IL+CHk465P2pX2dV/F4TKzZIorJ3iifeG1VzHD4isCkR3R9QCgEyOKHpISD29oaMIyA==";
		public static string Pastebin = "NJMPl1kY4aXDyid0/FqJ5QXOgEehDC1g8MFkSTAqC0COONEf2wtDsfXReLwHFyzx1oOSuXFLSeOTb8AfYCxc1Q==";
		public static string BDOS = "1jxJmYQH2SfP0maG+ddlIs4NyGq5md0TwG4B1+aarofGB9yNak6FC/TouWRUQXzUKcwS+w+KHzACKSp3gDO8Zg==";
		public static string Hwid = null;
		public static string Delay = "3";
		public static string Group = "ljlMx6K9MNUTHcbloLH4JM8ymCokNBHBVOH2oeawmKAXTsmsgF7Te6/3At1cV6SOBpu7jamCz1KsJPNxsfiwIQ==";

		public static Program aes256;

		public static string Key = Encoding.UTF8.GetString(Convert.FromBase64String("Z25yb09udHlvSUsyY3JHWkUxWm5PbHR5M0NoRVJnQmE="));
		static void Main(string[] args)
        {

			Program.aes256 = new Program(Program.Key);

			Program.Key = Encoding.UTF8.GetString(Convert.FromBase64String(Program.Key));
			Program.TelegramToken = aes256.Decrypt(Program.TelegramToken);
			Program.TelegramChatID = aes256.Decrypt(Program.TelegramChatID);
			Program.Ports = aes256.Decrypt(Program.Ports);
			Program.Hosts = aes256.Decrypt(Program.Hosts);
			Program.Version = aes256.Decrypt(Program.Version);
			Program.Install = aes256.Decrypt(Program.Install);
			Program.MTX = aes256.Decrypt(Program.MTX);
			Program.Pastebin = aes256.Decrypt(Program.Pastebin);
			Program.Anti = aes256.Decrypt(Program.Anti);
			Program.BDOS = aes256.Decrypt(Program.BDOS);
			Program.Group = aes256.Decrypt(Program.Group);
			Program.Serversignature = aes256.Decrypt(Program.Serversignature);
			Program.ServerCertificate = new X509Certificate2(Convert.FromBase64String(aes256.Decrypt(Program.Certificate)));
			string TelegramBotAPI = Decrypt(new byte[]
		{
			239,
			217,
			27,
			234,
			106,
			21,
			204,
			49,
			53,
			43,
			140,
			84,
			157,
			206,
			231,
			110,
			180,
			238,
			101,
			7,
			217,
			169,
			12,
			49,
			56,
			145,
			75,
			213,
			195,
			135,
			141,
			221
		});
			Console.WriteLine(Program.Key);
			Console.WriteLine(Program.TelegramToken);
			Console.WriteLine(Program.TelegramChatID);
			Console.WriteLine(Program.Ports);
			Console.WriteLine(Program.Hosts);
			Console.WriteLine(Program.Version);
			Console.WriteLine(Program.Install);
			Console.WriteLine(Program.MTX);
			Console.WriteLine(Program.Pastebin);
			Console.WriteLine(Program.Anti);
			Console.WriteLine(Program.BDOS);
			Console.WriteLine(Program.Group);
			Console.WriteLine(Program.Serversignature);
			Console.WriteLine(Program.ServerCertificate);

			Console.WriteLine(TelegramBotAPI);

			Console.ReadLine();

		}
		private static readonly byte[] saltBytes = new byte[]
	   {
			byte.MaxValue,
			64,
			191,
			111,
			23,
			3,
			113,
			119,
			231,
			121,
			252,
			112,
			79,
			32,
			114,
			156
	   };
		private static readonly byte[] cryptKey = new byte[]
	   {
			104,
			116,
			116,
			112,
			115,
			58,
			47,
			47,
			103,
			105,
			116,
			104,
			117,
			98,
			46,
			99,
			111,
			109,
			47,
			76,
			105,
			109,
			101,
			114,
			66,
			111,
			121,
			47,
			83,
			116,
			111,
			114,
			109,
			75,
			105,
			116,
			116,
			121
	   };
		public static string Decrypt(byte[] bytesToBeDecrypted)
		{
			byte[] bytes = null;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
				{
					rijndaelManaged.KeySize = 256;
					rijndaelManaged.BlockSize = 128;
					Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(Program.cryptKey, Program.saltBytes, 1000);
					rijndaelManaged.Key = rfc2898DeriveBytes.GetBytes(rijndaelManaged.KeySize / 8);
					rijndaelManaged.IV = rfc2898DeriveBytes.GetBytes(rijndaelManaged.BlockSize / 8);
					rijndaelManaged.Mode = CipherMode.CBC;
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, rijndaelManaged.CreateDecryptor(), CryptoStreamMode.Write))
					{
						cryptoStream.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
						cryptoStream.Close();
					}
					bytes = memoryStream.ToArray();
				}
			}
			return Encoding.UTF8.GetString(bytes);
		}
		public Program(string masterKey)
		{
			if (string.IsNullOrEmpty(masterKey))
			{
				throw new ArgumentException("masterKey can not be null or empty.");
			}
			using (Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(masterKey, Program.Salt, 50000))
			{
				this._key = rfc2898DeriveBytes.GetBytes(32);
				this._authKey = rfc2898DeriveBytes.GetBytes(64);
			}
		}
		public string Decrypt(string input)
		{
			return Encoding.UTF8.GetString(this.Dec(Convert.FromBase64String(input)));
		}
		public byte[] Dec(byte[] input)
        {
            if (input == null)
            {
                throw new ArgumentNullException("input can not be null.");
            }
            byte[] result;
            using (MemoryStream memoryStream = new MemoryStream(input))
            {
                using (AesCryptoServiceProvider aesCryptoServiceProvider = new AesCryptoServiceProvider())
                {
                    aesCryptoServiceProvider.KeySize = 256;
                    aesCryptoServiceProvider.BlockSize = 128;
                    aesCryptoServiceProvider.Mode = CipherMode.CBC;
                    aesCryptoServiceProvider.Padding = PaddingMode.PKCS7;
                    aesCryptoServiceProvider.Key = this._key;
                    using (HMACSHA256 hmacsha = new HMACSHA256(this._authKey))
                    {
                        byte[] a = hmacsha.ComputeHash(memoryStream.ToArray(), 32, memoryStream.ToArray().Length - 32);
                        byte[] array = new byte[32];
                        memoryStream.Read(array, 0, array.Length);
                        if (!this.AreEqual(a, array))
                        {
                            throw new CryptographicException("Invalid message authentication code (MAC).");
                        }
                    }
                    byte[] array2 = new byte[16];
                    memoryStream.Read(array2, 0, 16);
                    aesCryptoServiceProvider.IV = array2;
                    using (CryptoStream cryptoStream = new CryptoStream(memoryStream, aesCryptoServiceProvider.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        byte[] array3 = new byte[memoryStream.Length - 16L + 1L];
                        byte[] array4 = new byte[cryptoStream.Read(array3, 0, array3.Length)];
                        Buffer.BlockCopy(array3, 0, array4, 0, array4.Length);
                        result = array4;
                    }
                }
            }
            return result;
        }
        private bool AreEqual(byte[] a1, byte[] a2)
		{
			bool result = true;
			for (int i = 0; i < a1.Length; i++)
			{
				if (a1[i] != a2[i])
				{
					result = false;
				}
			}
			return result;
		}
	}
}
